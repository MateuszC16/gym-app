class App {
  constructor() {
    this.addEventListeners();
    this.renderExercises();  // Wyświetlamy ćwiczenia po załadowaniu
  }

  // Funkcja do dodawania ćwiczenia
  async addExercise(exercise) {
    const response = await fetch('/api/exercises', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exercise)
    });
    const newExercise = await response.json();
    this.renderExercises();  // Aktualizujemy listę ćwiczeń
  }

  // Funkcja do renderowania ćwiczeń na stronie
  async renderExercises() {
    const response = await fetch('/api/exercises');
    const exercises = await response.json();
    const exerciseList = document.getElementById('exercise-list');  // Element na stronie

    exerciseList.innerHTML = '';  // Czyścimy poprzednią listę

    // Renderujemy każde ćwiczenie
    exercises.forEach(exercise => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${exercise.name}</td>
        <td>${exercise.muscle_group}</td>
        <td>${exercise.current_weight} kg</td>
        <td>${exercise.max_weight} kg</td>
      `;
      exerciseList.appendChild(tr);
    });
  }

  // Funkcja do obsługi formularza
  addEventListeners() {
    document.getElementById('exercise-form').addEventListener('submit', (event) => {
      event.preventDefault();  // Zapobiegamy domyślnemu wysyłaniu formularza

      // Pobieramy dane z formularza
      const name = document.getElementById('name').value;
      const muscleGroup = document.getElementById('muscle-group').value;
      const currentWeight = parseFloat(document.getElementById('current-weight').value);
      const maxWeight = parseFloat(document.getElementById('max-weight').value);

      const newExercise = {
        name,
        muscleGroup,
        currentWeight,
        maxWeight
      };

      this.addExercise(newExercise);  // Dodajemy ćwiczenie do backendu
      document.getElementById('exercise-form').reset();  // Czyścimy formularz
    });
  }
}

// Inicjalizujemy aplikację
const app = new App();
