class Exercise {
    constructor(name, muscleGroup, currentWeight, maxWeight) {
      this.name = name;
      this.muscleGroup = muscleGroup;
      this.currentWeight = currentWeight;
      this.maxWeight = maxWeight;
    }
  
    // Funkcja do wyświetlania ćwiczenia w UI
    render() {
      const exerciseContainer = document.createElement('div');
      exerciseContainer.classList.add('exercise');
      exerciseContainer.innerHTML = `
        <h3>${this.name}</h3>
        <p>Muscle Group: ${this.muscleGroup}</p>
        <p>Current Weight: ${this.currentWeight} kg</p>
        <p>Max Weight: ${this.maxWeight} kg</p>
      `;
      return exerciseContainer;
    }
  }
  
  export default Exercise;  // Eksportujemy klasę Exercise
  