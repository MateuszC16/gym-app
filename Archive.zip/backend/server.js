import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';  // Do uzyskiwania __dirname w ES Modules
import pkg from 'pg';  // Importujemy całą bibliotekę 'pg' jako domyślny eksport

const { Client } = pkg;  // Wyciągamy Client z obiektu 'pg'

// Uzyskujemy katalog bieżącego pliku
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Tworzymy aplikację Express
const app = express();

// Umożliwiamy obsługę JSON w ciałach żądań
app.use(express.json());

// Umożliwiamy obsługę plików statycznych (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'frontend')));  // Zakładając, że frontend jest w folderze 'frontend'

// Połączenie z bazą danych PostgreSQL
const client = new Client({
  user: 'postgres',      // Użytkownik bazy danych
  host: 'localhost',
  database: 'gym_app',   // Nazwa bazy danych
  password: 'admin',     // Hasło bazy danych
  port: 5432,            // Port bazy danych
});

// Łączymy się z bazą
client.connect()
  .then(() => {
    console.log('Połączono z bazą danych PostgreSQL');
  })
  .catch(err => {
    console.error('Błąd połączenia z bazą:', err);
  });

// Endpoint do pobierania ćwiczeń
app.get('/api/exercises', async (req, res) => {
  try {
    const result = await client.query('SELECT * FROM exercises');
    res.json(result.rows);  // Odpowiadamy danymi ćwiczeń w formacie JSON
  } catch (err) {
    res.status(500).json({ error: 'Błąd przy pobieraniu ćwiczeń z bazy danych' });
  }
});

// Endpoint do dodawania ćwiczenia
app.post('/api/exercises', async (req, res) => {
  const { name, muscleGroup, currentWeight, maxWeight } = req.body;
  try {
    const result = await client.query(
      'INSERT INTO exercises(name, muscle_group, current_weight, max_weight) VALUES($1, $2, $3, $4) RETURNING *',
      [name, muscleGroup, currentWeight, maxWeight]
    );
    res.json(result.rows[0]);  // Odpowiadamy dodanym ćwiczeniem
  } catch (err) {
    res.status(500).json({ error: 'Błąd przy dodawaniu ćwiczenia' });
  }
});

// Serwer nasłuchuje na porcie 3000
app.listen(3000, () => {
  console.log('Backend działa na http://localhost:3000');
});
